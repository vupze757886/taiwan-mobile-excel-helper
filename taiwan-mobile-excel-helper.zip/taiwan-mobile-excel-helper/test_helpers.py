import unittest

from twm_excel_helper import (
    find_column,
    mask,
    normalize_phone,
    normalize_subscriber_id,
    valid_row,
)


class HelperTests(unittest.TestCase):
    def test_columns_and_normalization(self):
        headers = ["姓名", "身分證字號", "完整地址", "電話"]
        self.assertEqual(find_column(headers, {"電話"}), 4)
        self.assertEqual(normalize_phone(912345678), "0912345678")
        self.assertEqual(normalize_phone("0912-345-678"), "0912345678")
        self.assertEqual(normalize_subscriber_id(" a123456789 "), "A123456789")

    def test_validation(self):
        self.assertEqual(valid_row("0912345678", "A123456789"), (True, ""))
        self.assertFalse(valid_row("912345678", "A123456789")[0])
        self.assertFalse(valid_row("0912345678", "1234567890")[0])

    def test_mask(self):
        self.assertEqual(mask("0912345678"), "09******78")


if __name__ == "__main__":
    unittest.main()
