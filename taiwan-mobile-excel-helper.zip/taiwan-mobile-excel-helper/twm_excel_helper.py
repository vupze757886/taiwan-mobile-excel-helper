#!/usr/bin/env python3
"""Human-in-the-loop Excel form filler for Taiwan Mobile's public payment page.

The program deliberately does not read, solve, or bypass CAPTCHA challenges.
It fills the phone and subscriber ID fields, then waits for the user to enter
the CAPTCHA and submit the form manually. The user records the observed result
with a short keyboard choice, which is written back to a copy of the workbook.
"""

from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Iterable

from openpyxl import load_workbook


DEFAULT_URL = (
    "https://www.taiwanmobile.com/cs/public/debitCardPayment/"
    "authenticateNonMember.htm"
)

PHONE_HEADERS = {"電話", "手機", "手機號碼", "門號", "行動電話", "mobile", "phone"}
ID_HEADERS = {"身分證字號", "身分證", "證號", "用戶證號", "id", "subscriberid"}
NAME_HEADERS = {"姓名", "名字", "name"}

STATUS_HEADER = "查詢狀態"
TIME_HEADER = "查詢時間"
NOTE_HEADER = "查詢備註"


def normalized_header(value: object) -> str:
    return re.sub(r"[\s_\-｜|]+", "", str(value or "")).lower()


def find_column(headers: Iterable[object], aliases: set[str]) -> int | None:
    normalized_aliases = {normalized_header(alias) for alias in aliases}
    for index, value in enumerate(headers, start=1):
        if normalized_header(value) in normalized_aliases:
            return index
    return None


def normalize_phone(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    digits = re.sub(r"\D", "", str(value))
    if len(digits) == 9 and digits.startswith("9"):
        digits = "0" + digits
    return digits


def normalize_subscriber_id(value: object) -> str:
    if value is None:
        return ""
    return re.sub(r"\s", "", str(value)).upper()


def mask(value: str, keep_start: int = 2, keep_end: int = 2) -> str:
    if len(value) <= keep_start + keep_end:
        return "*" * len(value)
    return value[:keep_start] + "*" * (len(value) - keep_start - keep_end) + value[-keep_end:]


def ensure_output_columns(ws) -> tuple[int, int, int]:
    headers = [cell.value for cell in ws[1]]
    columns: list[int] = []
    for label in (STATUS_HEADER, TIME_HEADER, NOTE_HEADER):
        existing = find_column(headers, {label})
        if existing is None:
            existing = ws.max_column + 1
            ws.cell(1, existing, label)
            headers.append(label)
        columns.append(existing)
    return tuple(columns)  # type: ignore[return-value]


def pick_sheet(workbook, requested: str | None):
    if requested:
        if requested not in workbook.sheetnames:
            raise ValueError(
                f"找不到工作表「{requested}」。可用工作表：{', '.join(workbook.sheetnames)}"
            )
        return workbook[requested]
    return workbook.active


def resolve_input_columns(ws) -> tuple[int | None, int, int]:
    headers = [cell.value for cell in ws[1]]
    phone_col = find_column(headers, PHONE_HEADERS)
    id_col = find_column(headers, ID_HEADERS)
    name_col = find_column(headers, NAME_HEADERS)
    missing = []
    if phone_col is None:
        missing.append("電話／手機號碼")
    if id_col is None:
        missing.append("身分證字號")
    if missing:
        raise ValueError("缺少必要欄位：" + "、".join(missing))
    return name_col, phone_col, id_col


def valid_row(phone: str, subscriber_id: str) -> tuple[bool, str]:
    if not re.fullmatch(r"09\d{8}", phone):
        return False, "電話格式不是 09 開頭的 10 碼門號"
    if not re.fullmatch(r"[A-Z][12]\d{8}", subscriber_id):
        return False, "身分證字號格式不符"
    return True, ""


def fill_first(locator_candidates, value: str, field_name: str) -> None:
    for locator in locator_candidates:
        try:
            if locator.count() and locator.first.is_visible():
                locator.first.fill(value)
                return
        except Exception:
            continue
    raise RuntimeError(f"找不到可填寫的{field_name}欄位。請用 --url 確認網址是否正確。")


def fill_identity_fields(page, phone: str, subscriber_id: str) -> None:
    phone_candidates = [
        page.get_by_label(re.compile(r"(手機|門號|行動電話)")).first,
        page.locator(
            'input[id*="phone" i], input[name*="phone" i], '
            'input[id*="mobile" i], input[name*="mobile" i], '
            'input[placeholder*="門號"], input[placeholder*="手機"]'
        ).first,
    ]
    id_candidates = [
        page.get_by_label(re.compile(r"(身分證|證號|用戶證號)")).first,
        page.locator(
            'input[id*="idno" i], input[name*="idno" i], '
            'input[id*="subscriber" i], input[name*="subscriber" i], '
            'input[placeholder*="身分證"], input[placeholder*="證號"]'
        ).first,
    ]
    fill_first(phone_candidates, phone, "手機門號")
    fill_first(id_candidates, subscriber_id, "身分證字號")


def prompt_result() -> tuple[str, str, bool]:
    print("\n請在瀏覽器中手動輸入驗證碼並送出，查看網頁顯示結果。")
    print("1=可進入繳費頁  2=無法繳費/查無資料  3=驗證碼錯誤重試  4=略過  5=停止")
    while True:
        choice = input("請輸入結果代碼：").strip()
        if choice == "1":
            return "可進入繳費頁", "僅代表此頁本次可繼續，不等於門號歸屬查證", False
        if choice == "2":
            note = input("可選填網頁顯示文字或原因：").strip()
            base = "無法由此結果單獨判定是否攜碼或已非台灣大哥大"
            return "無法繳費或查無資料", f"{base}；{note}" if note else base, False
        if choice == "3":
            return "", "", True
        if choice == "4":
            return "略過", "由使用者略過", False
        if choice == "5":
            raise KeyboardInterrupt
        print("請輸入 1、2、3、4 或 5。")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="從 Excel 逐筆填寫手機門號與身分證字號；驗證碼由使用者手動完成。"
    )
    parser.add_argument("input", type=Path, help="來源 .xlsx 檔案")
    parser.add_argument("--output", type=Path, help="輸出檔案，預設為來源檔名_查詢結果.xlsx")
    parser.add_argument("--sheet", help="工作表名稱，預設使用目前作用中的工作表")
    parser.add_argument("--url", default=DEFAULT_URL, help="查詢頁網址")
    parser.add_argument("--start-row", type=int, default=2, help="開始資料列，預設 2")
    parser.add_argument("--dry-run", action="store_true", help="只檢查欄位與資料，不開啟瀏覽器")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.input.suffix.lower() != ".xlsx" or not args.input.exists():
        print("錯誤：請指定存在的 .xlsx 檔案。", file=sys.stderr)
        return 2

    output = args.output or args.input.with_name(args.input.stem + "_查詢結果.xlsx")
    if output.resolve() == args.input.resolve():
        print("錯誤：輸出檔不可覆蓋來源檔。", file=sys.stderr)
        return 2
    output.parent.mkdir(parents=True, exist_ok=True)

    workbook = load_workbook(args.input)
    try:
        ws = pick_sheet(workbook, args.sheet)
        name_col, phone_col, id_col = resolve_input_columns(ws)
    except ValueError as exc:
        print(f"錯誤：{exc}", file=sys.stderr)
        return 2

    status_col, time_col, note_col = ensure_output_columns(ws)
    rows = []
    for row in range(max(2, args.start_row), ws.max_row + 1):
        phone = normalize_phone(ws.cell(row, phone_col).value)
        subscriber_id = normalize_subscriber_id(ws.cell(row, id_col).value)
        if not phone and not subscriber_id:
            continue
        rows.append((row, phone, subscriber_id))

    print(f"工作表：{ws.title}；待檢查資料列：{len(rows)}")
    if args.dry_run:
        invalid = 0
        for row, phone, subscriber_id in rows:
            ok, reason = valid_row(phone, subscriber_id)
            if not ok:
                invalid += 1
                print(f"第 {row} 列：{reason}")
        workbook.save(output)
        print(f"欄位檢查完成；格式異常 {invalid} 列；已建立：{output}")
        return 0

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print(
            "錯誤：尚未安裝 Playwright。請依 README 執行安裝指令。",
            file=sys.stderr,
        )
        return 2

    stop_requested = False
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=False)
            page = browser.new_page()
            for row, phone, subscriber_id in rows:
                if ws.cell(row, status_col).value:
                    continue
                ok, reason = valid_row(phone, subscriber_id)
                if not ok:
                    ws.cell(row, status_col, "資料格式錯誤")
                    ws.cell(row, time_col, datetime.now())
                    ws.cell(row, note_col, reason)
                    workbook.save(output)
                    continue

                display_name = str(ws.cell(row, name_col).value or "").strip() if name_col else ""
                print(
                    f"\n第 {row} 列 {display_name} "
                    f"電話 {mask(phone)}／證號 {mask(subscriber_id)}"
                )
                while True:
                    page.goto(args.url, wait_until="domcontentloaded")
                    fill_identity_fields(page, phone, subscriber_id)
                    try:
                        status, note, retry = prompt_result()
                    except KeyboardInterrupt:
                        stop_requested = True
                        break
                    if retry:
                        continue
                    ws.cell(row, status_col, status)
                    ws.cell(row, time_col, datetime.now())
                    ws.cell(row, note_col, note)
                    workbook.save(output)
                    break
                if stop_requested:
                    break
            browser.close()
    except KeyboardInterrupt:
        stop_requested = True
    finally:
        workbook.save(output)

    print(f"已儲存：{output}")
    if stop_requested:
        print("已停止；下次用同一輸出檔當來源，可從未完成列繼續。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
